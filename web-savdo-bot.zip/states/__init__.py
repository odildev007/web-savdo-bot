from aiogram.fsm.state import State, StatesGroup

class UserRegistration(StatesGroup):
    user_name = State()
    phone_number = State()

class UserSendMessage(StatesGroup):
    message = State()