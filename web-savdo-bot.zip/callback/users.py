from aiogram import Bot
from aiogram.types import CallbackQuery
import apiClient
import keyboards

async def check_user(callback: CallbackQuery, bot: Bot):
    status = "user" if callback.data.split(":")[1] == "user" else "ban"
    user_id = callback.data.split(":")[2]

    status_code = await apiClient.users.change_user_status(user_id, status)
    if status_code == 200:
        await callback.answer("✅ So'rov muvaffaqiyatli bajarildi!", show_alert=True)
        if status == "user": await bot.send_message(user_id, "✅ Profilingiz tasdiqlandi!", reply_markup=keyboards.reply.main_menu(user_id))
    else: await callback.answer(f"❗ Xatolik!\n\nSTATUS_CODE: {status_code}", show_alert=True)
    await callback.message.delete()
