from aiogram import Router, F
from . import users

router = Router()

router.callback_query.register(users.check_user, F.data.startswith("checkuser"))