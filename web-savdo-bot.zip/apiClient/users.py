from asyncio import run
from aiohttp import ClientSession
from config import ADMINS
from config import api_url as url
from json import JSONDecoder


async def add_user(user_id, user_name, phone_number):
    async with ClientSession() as session:
        status = "wait"
        if user_id in ADMINS: status = "admin" 
        data = {"user_id": user_id, "user_name": user_name, "phone_number": phone_number, "balance": 0, "status": status}
        async with session.post(url + "users/", data=data) as response:
            return response.status

async def change_user_status(user_id, status):
    async with ClientSession() as session:
        data = {"status": status}
        async with session.patch(url + f"users/{user_id}", data=data) as response:
            return response.status

async def get_users():
    async with ClientSession() as session:
        async with session.get(url + "users/") as response:
            return await response.json()

async def get_user(user_id):
    async with ClientSession() as session:
        async with session.get(url + f"users/{user_id}") as response:
            return await response.json()
