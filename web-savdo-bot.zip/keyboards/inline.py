from aiogram.utils.keyboard import InlineKeyboardBuilder

def check_user(user_id):
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Tasdiqlash", callback_data=f"checkuser:user:{user_id}")
    builder.button(text="❌ Rad etish", callback_data=f"checkuser:ban:{user_id}")
    return builder.as_markup()