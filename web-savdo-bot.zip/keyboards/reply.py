from aiogram.utils.keyboard import ReplyKeyboardBuilder
from aiogram.types.web_app_info import WebAppInfo
import config


phone_number_builder = ReplyKeyboardBuilder()
phone_number_builder.button(text="telefon raqamni yuborish", request_contact=True)
phone_number_builder = phone_number_builder.as_markup()
phone_number_builder.resize_keyboard = True

def main_menu(user_id):
    main_menu = ReplyKeyboardBuilder()
    main_menu.button(text="Web interfeysni ochish",web_app=WebAppInfo(url=config.web_app_url))
    main_menu = main_menu.as_markup()
    main_menu.resize_keyboard = True
    return main_menu