from aiogram.types import Message
from aiogram.filters import Filter
import apiClient, config

class NotUserInDB(Filter):
    async def __call__(sself, message: Message):
        users = await apiClient.users.get_users()
        if list(filter(lambda user: user["user_id"] == message.from_user.id, users)): return True

class CheckWaitUser(Filter):
    async def __call__(sself, message: Message):
        user = await apiClient.users.get_user(message.from_user.id)
        return user.get("status") == "wait"
           
class CheckBanUser(Filter):
    async def __call__(sself, message: Message):
        user = await apiClient.users.get_user(message.from_user.id)
        return user.get("status") == "ban"

class IsAdmin(Filter):
    async def __call__(self, message: Message):
        return message.from_user.id in config.ADMINS