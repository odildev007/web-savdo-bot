from aiogram import Bot, Dispatcher
import asyncio, config
import message, callback

dp = Dispatcher()

async def main():
    bot = Bot(token=config.TOKEN)

    dp.include_router(message.router)
    dp.include_router(callback.router)

    print("\033[32mBot ishga tushdi!\033[0m")
    await dp.start_polling(bot)
    print("\033[31mBot ishdan to'xtadi!\033[0m")

asyncio.run(main=main())