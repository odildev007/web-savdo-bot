from aiogram import Router, F
from aiogram.filters import and_f
import filters.registration
from . import any
from . import admin
import filters
import states
router = Router()

router.message.register(admin.users_send_message_message_answer, states.UserSendMessage.message)
router.message.register(any.user_name_nswer, states.UserRegistration.user_name)
router.message.register(any.phone_number_answer, states.UserRegistration.phone_number)
router.message.register(any.not_in_db_answer, filters.registration.NotUserInDB())
router.message.register(any.wait_user_answer, filters.registration.CheckWaitUser())
router.message.register(any.ban_user_answer, filters.registration.CheckBanUser())
router.message.register(admin.users_send_message, and_f(filters.registration.IsAdmin(), F.text == "/send"))
router.message.register(any.user_answer)
