from aiogram import Bot
from aiogram.types import Message
from aiogram import exceptions
from aiogram.fsm.context import FSMContext
import apiClient
import states
import asyncio


async def users_send_message(message: Message, state: FSMContext):
    await message.answer("Menga foydalanuvchilarga yubormoqchi bo'lgan xabaringizni yuboring.")
    await state.set_state(states.UserSendMessage.message)

async def users_send_message_message_answer(message: Message, state: FSMContext):
    sleep = 0.5
    sending_message = message
    all_users_id = []
    for user in apiClient.users.get_users():
        all_users_id.append(user["user_id"])


    async def send_message(user_id: int, message: Message) -> bool:
        success = False
        flood = False
        try:
            await message.send_copy(chat_id=user_id)
            success = True
        except exceptions.TelegramRetryAfter as flood_error:
            await asyncio.sleep(flood_error.retry_after)
            flood = True
        finally:
            if flood:
                return await send_message(user_id, message)
            return success

    successfully_sent = 0
    for user in all_users_id:
        sent = await send_message(user, sending_message)
        if sent:
            successfully_sent += 1
        await asyncio.sleep(sleep)

    await message.answer(f"✅ Xabar {successfully_sent} ta foydalanuvchiga yetkazildi!")
    await state.clear()