from aiogram import Bot
from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.fsm.context import FSMContext
import states
import keyboards
import apiClient
import config

async def not_in_db_answer(message: Message, state: FSMContext):
    await message.answer("Assalomu alaykum, botimizga xush kelibsiz!")
    await message.answer("Sizni adminga kim deb tanishtiray?", reply_markup=ReplyKeyboardRemove())
    await state.set_state(states.UserRegistration.user_name)

async def user_name_nswer(message: Message, state: FSMContext):
    await state.update_data(user_name=message.text)
    await message.answer("Endi telefon raqamni yuborish tugmasiga bosib, telefon raqamingizni yuboring.", reply_markup=keyboards.reply.phone_number_builder)
    await state.set_state(states.UserRegistration.phone_number)

async def phone_number_answer(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    if message.from_user.id == message.contact.user_id:
        phone_number = message.contact.phone_number
        if not phone_number.startswith("+"): phone_number = "+" + phone_number
        await apiClient.users.add_user(message.from_user.id, data.get("user_name"), phone_number)
        await message.answer("Siz ro'yhatdan o'tdingiz! Endi admin sizni tasdiqlashini kutishingiz kerak.")
        for admin in config.ADMINS:
            await bot.send_message(admin, f"YANGI FOYDALANUVCHI:\n\nIsm-familya: {data.get('user_name')}\nTelefon raqami: {phone_number}", reply_markup=keyboards.inline.check_user(message.from_user.id))
        await state.clear()
    else: await message.answer("Telefon raqamni yuborish tugmasiga bosing.", reply_markup=keyboards.reply.phone_number_builder)

async def wait_user_answer(message: Message):
    await message.answer("❗ Sizning profilingiz hali admin tomonidan ko'rib chiqilmadi!")
    
async def ban_user_answer(message: Message):
    await message.answer("❗ Sizning profilingiz admin tomonidan rad etilgan!")

async def user_answer(message: Message):
    await message.answer("Sizga yordam berishim uchun web interfeysni ochish tugmasiga bosing.", reply_markup=keyboards.reply.main_menu(message.from_user.id))