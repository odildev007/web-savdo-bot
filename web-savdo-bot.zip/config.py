TOKEN = "6923568104:AAE6sKkprU8AUdiudkxIdFEak23CBDeYwTM"
ADMINS = [5165396993]
api_url = "http://16.171.142.39:8000/"
web_app_url = "https://kun.uz/"